"use strict";
/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunkvue_antd_pro"] = self["webpackChunkvue_antd_pro"] || []).push([["lang-zh-CN-global"],{

/***/ "./src/locales/lang/zh-CN/global.js":
/*!******************************************!*\
  !*** ./src/locales/lang/zh-CN/global.js ***!
  \******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony default export */ __webpack_exports__[\"default\"] = ({\n  submit: '提交',\n  save: '保存',\n  'submit.ok': '提交成功',\n  'save.ok': '保存成功'\n});\n\n//# sourceURL=webpack://vue-antd-pro/./src/locales/lang/zh-CN/global.js?\n}");

/***/ })

}]);