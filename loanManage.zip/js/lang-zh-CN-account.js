"use strict";
/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunkvue_antd_pro"] = self["webpackChunkvue_antd_pro"] || []).push([["lang-zh-CN-account"],{

/***/ "./src/locales/lang/zh-CN/account.js":
/*!*******************************************!*\
  !*** ./src/locales/lang/zh-CN/account.js ***!
  \*******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var F_appMode_loan_manage_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ \"./node_modules/@babel/runtime/helpers/esm/objectSpread2.js\");\n/* harmony import */ var _account_settings__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./account/settings */ \"./src/locales/lang/zh-CN/account/settings.js\");\n\n\n/* harmony default export */ __webpack_exports__[\"default\"] = ((0,F_appMode_loan_manage_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__[\"default\"])({}, _account_settings__WEBPACK_IMPORTED_MODULE_1__[\"default\"]));\n\n//# sourceURL=webpack://vue-antd-pro/./src/locales/lang/zh-CN/account.js?\n}");

/***/ }),

/***/ "./src/locales/lang/zh-CN/account/settings.js":
/*!****************************************************!*\
  !*** ./src/locales/lang/zh-CN/account/settings.js ***!
  \****************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony default export */ __webpack_exports__[\"default\"] = ({\n  'account.settings.menuMap.basic': '基本设置',\n  'account.settings.menuMap.security': '安全设置',\n  'account.settings.menuMap.custom': '个性化',\n  'account.settings.menuMap.binding': '账号绑定',\n  'account.settings.menuMap.notification': '新消息通知',\n  'account.settings.basic.avatar': '头像',\n  'account.settings.basic.change-avatar': '更换头像',\n  'account.settings.basic.email': '邮箱',\n  'account.settings.basic.email-message': '请输入您的邮箱!',\n  'account.settings.basic.nickname': '昵称',\n  'account.settings.basic.nickname-message': '请输入您的昵称!',\n  'account.settings.basic.profile': '个人简介',\n  'account.settings.basic.profile-message': '请输入个人简介!',\n  'account.settings.basic.profile-placeholder': '个人简介',\n  'account.settings.basic.country': '国家/地区',\n  'account.settings.basic.country-message': '请输入您的国家或地区!',\n  'account.settings.basic.geographic': '所在省市',\n  'account.settings.basic.geographic-message': '请输入您的所在省市!',\n  'account.settings.basic.address': '街道地址',\n  'account.settings.basic.address-message': '请输入您的街道地址!',\n  'account.settings.basic.phone': '联系电话',\n  'account.settings.basic.phone-message': '请输入您的联系电话!',\n  'account.settings.basic.update': '更新基本信息',\n  'account.settings.basic.update.success': '更新基本信息成功',\n  'account.settings.security.strong': '强',\n  'account.settings.security.medium': '中',\n  'account.settings.security.weak': '弱',\n  'account.settings.security.password': '账户密码',\n  'account.settings.security.password-description': '当前密码强度：',\n  'account.settings.security.phone': '密保手机',\n  'account.settings.security.phone-description': '已绑定手机：',\n  'account.settings.security.question': '密保问题',\n  'account.settings.security.question-description': '未设置密保问题，密保问题可有效保护账户安全',\n  'account.settings.security.email': '备用邮箱',\n  'account.settings.security.email-description': '已绑定邮箱：',\n  'account.settings.security.mfa': 'MFA 设备',\n  'account.settings.security.mfa-description': '未绑定 MFA 设备，绑定后，可以进行二次确认',\n  'account.settings.security.modify': '修改',\n  'account.settings.security.set': '设置',\n  'account.settings.security.bind': '绑定',\n  'account.settings.binding.taobao': '绑定淘宝',\n  'account.settings.binding.taobao-description': '当前未绑定淘宝账号',\n  'account.settings.binding.alipay': '绑定支付宝',\n  'account.settings.binding.alipay-description': '当前未绑定支付宝账号',\n  'account.settings.binding.dingding': '绑定钉钉',\n  'account.settings.binding.dingding-description': '当前未绑定钉钉账号',\n  'account.settings.binding.bind': '绑定',\n  'account.settings.notification.password': '账户密码',\n  'account.settings.notification.password-description': '其他用户的消息将以站内信的形式通知',\n  'account.settings.notification.messages': '系统消息',\n  'account.settings.notification.messages-description': '系统消息将以站内信的形式通知',\n  'account.settings.notification.todo': '待办任务',\n  'account.settings.notification.todo-description': '待办任务将以站内信的形式通知',\n  'account.settings.settings.open': '开',\n  'account.settings.settings.close': '关'\n});\n\n//# sourceURL=webpack://vue-antd-pro/./src/locales/lang/zh-CN/account/settings.js?\n}");

/***/ })

}]);