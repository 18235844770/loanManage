"use strict";
/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunkvue_antd_pro"] = self["webpackChunkvue_antd_pro"] || []).push([["lang-zh-CN-form-basicForm"],{

/***/ "./src/locales/lang/zh-CN/form/basicForm.js":
/*!**************************************************!*\
  !*** ./src/locales/lang/zh-CN/form/basicForm.js ***!
  \**************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony default export */ __webpack_exports__[\"default\"] = ({\n  'form.basic-form.basic.title': '基础表单',\n  'form.basic-form.basic.description': '表单页用于向用户收集或验证信息，基础表单常见于数据项较少的表单场景。',\n  'form.basic-form.title.label': '标题',\n  'form.basic-form.title.placeholder': '给目标起个名字',\n  'form.basic-form.title.required': '请输入标题',\n  'form.basic-form.date.label': '起止日期',\n  'form.basic-form.placeholder.start': '开始日期',\n  'form.basic-form.placeholder.end': '结束日期',\n  'form.basic-form.date.required': '请选择起止日期',\n  'form.basic-form.goal.label': '目标描述',\n  'form.basic-form.goal.placeholder': '请输入你的阶段性工作目标',\n  'form.basic-form.goal.required': '请输入目标描述',\n  'form.basic-form.standard.label': '衡量标准',\n  'form.basic-form.standard.placeholder': '请输入衡量标准',\n  'form.basic-form.standard.required': '请输入衡量标准',\n  'form.basic-form.client.label': '客户',\n  'form.basic-form.client.required': '请描述你服务的客户',\n  'form.basic-form.label.tooltip': '目标的服务对象',\n  'form.basic-form.client.placeholder': '请描述你服务的客户，内部客户直接 @姓名／工号',\n  'form.basic-form.invites.label': '邀评人',\n  'form.basic-form.invites.placeholder': '请直接 @姓名／工号，最多可邀请 5 人',\n  'form.basic-form.weight.label': '权重',\n  'form.basic-form.weight.placeholder': '请输入',\n  'form.basic-form.public.label': '目标公开',\n  'form.basic-form.label.help': '客户、邀评人默认被分享',\n  'form.basic-form.radio.public': '公开',\n  'form.basic-form.radio.partially-public': '部分公开',\n  'form.basic-form.radio.private': '不公开',\n  'form.basic-form.publicUsers.placeholder': '公开给',\n  'form.basic-form.option.A': '同事一',\n  'form.basic-form.option.B': '同事二',\n  'form.basic-form.option.C': '同事三',\n  'form.basic-form.email.required': '请输入邮箱地址！',\n  'form.basic-form.email.wrong-format': '邮箱地址格式错误！',\n  'form.basic-form.userName.required': '请输入用户名!',\n  'form.basic-form.password.required': '请输入密码！',\n  'form.basic-form.password.twice': '两次输入的密码不匹配!',\n  'form.basic-form.strength.msg': '请至少输入 6 个字符。请不要使用容易被猜到的密码。',\n  'form.basic-form.strength.strong': '强度：强',\n  'form.basic-form.strength.medium': '强度：中',\n  'form.basic-form.strength.short': '强度：太短',\n  'form.basic-form.confirm-password.required': '请确认密码！',\n  'form.basic-form.phone-number.required': '请输入手机号！',\n  'form.basic-form.phone-number.wrong-format': '手机号格式错误！',\n  'form.basic-form.verification-code.required': '请输入验证码！',\n  'form.basic-form.form.get-captcha': '获取验证码',\n  'form.basic-form.captcha.second': '秒',\n  'form.basic-form.form.optional': '（选填）',\n  'form.basic-form.form.submit': '提交',\n  'form.basic-form.form.save': '保存',\n  'form.basic-form.email.placeholder': '邮箱',\n  'form.basic-form.password.placeholder': '至少6位密码，区分大小写',\n  'form.basic-form.confirm-password.placeholder': '确认密码',\n  'form.basic-form.phone-number.placeholder': '手机号',\n  'form.basic-form.verification-code.placeholder': '验证码'\n});\n\n//# sourceURL=webpack://vue-antd-pro/./src/locales/lang/zh-CN/form/basicForm.js?\n}");

/***/ })

}]);