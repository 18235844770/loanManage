"use strict";
/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunkvue_antd_pro"] = self["webpackChunkvue_antd_pro"] || []).push([["lang-zh-CN-result"],{

/***/ "./src/locales/lang/zh-CN/result.js":
/*!******************************************!*\
  !*** ./src/locales/lang/zh-CN/result.js ***!
  \******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var F_appMode_loan_manage_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ \"./node_modules/@babel/runtime/helpers/esm/objectSpread2.js\");\n/* harmony import */ var _result_success__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./result/success */ \"./src/locales/lang/zh-CN/result/success.js\");\n/* harmony import */ var _result_fail__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./result/fail */ \"./src/locales/lang/zh-CN/result/fail.js\");\n\n\n\n/* harmony default export */ __webpack_exports__[\"default\"] = ((0,F_appMode_loan_manage_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__[\"default\"])((0,F_appMode_loan_manage_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__[\"default\"])({}, _result_success__WEBPACK_IMPORTED_MODULE_1__[\"default\"]), _result_fail__WEBPACK_IMPORTED_MODULE_2__[\"default\"]));\n\n//# sourceURL=webpack://vue-antd-pro/./src/locales/lang/zh-CN/result.js?\n}");

/***/ }),

/***/ "./src/locales/lang/zh-CN/result/fail.js":
/*!***********************************************!*\
  !*** ./src/locales/lang/zh-CN/result/fail.js ***!
  \***********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony default export */ __webpack_exports__[\"default\"] = ({\n  'result.fail.error.title': '提交失败',\n  'result.fail.error.description': '请核对并修改以下信息后，再重新提交。',\n  'result.fail.error.hint-title': '您提交的内容有如下错误：',\n  'result.fail.error.hint-text1': '您的账户已被冻结',\n  'result.fail.error.hint-btn1': '立即解冻',\n  'result.fail.error.hint-text2': '您的账户还不具备申请资格',\n  'result.fail.error.hint-btn2': '立即升级',\n  'result.fail.error.btn-text': '返回修改'\n});\n\n//# sourceURL=webpack://vue-antd-pro/./src/locales/lang/zh-CN/result/fail.js?\n}");

/***/ }),

/***/ "./src/locales/lang/zh-CN/result/success.js":
/*!**************************************************!*\
  !*** ./src/locales/lang/zh-CN/result/success.js ***!
  \**************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony default export */ __webpack_exports__[\"default\"] = ({\n  'result.success.title': '提交成功',\n  'result.success.description': '提交结果页用于反馈一系列操作任务的处理结果， 如果仅是简单操作，使用 Message 全局提示反馈即可。 本文字区域可以展示简单的补充说明，如果有类似展示 “单据”的需求，下面这个灰色区域可以呈现比较复杂的内容。',\n  'result.success.operate-title': '项目名称',\n  'result.success.operate-id': '项目 ID',\n  'result.success.principal': '负责人',\n  'result.success.operate-time': '生效时间',\n  'result.success.step1-title': '创建项目',\n  'result.success.step1-operator': '曲丽丽',\n  'result.success.step2-title': '部门初审',\n  'result.success.step2-operator': '周毛毛',\n  'result.success.step2-extra': '催一下',\n  'result.success.step3-title': '财务复核',\n  'result.success.step4-title': '完成',\n  'result.success.btn-return': '返回列表',\n  'result.success.btn-project': '查看项目',\n  'result.success.btn-print': '打印'\n});\n\n//# sourceURL=webpack://vue-antd-pro/./src/locales/lang/zh-CN/result/success.js?\n}");

/***/ })

}]);