"use strict";
/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunkvue_antd_pro"] = self["webpackChunkvue_antd_pro"] || []).push([["lang-zh-CN-setting"],{

/***/ "./src/locales/lang/zh-CN/setting.js":
/*!*******************************************!*\
  !*** ./src/locales/lang/zh-CN/setting.js ***!
  \*******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony default export */ __webpack_exports__[\"default\"] = ({\n  'app.setting.pagestyle': '整体风格设置',\n  'app.setting.pagestyle.light': '亮色菜单风格',\n  'app.setting.pagestyle.dark': '暗色菜单风格',\n  'app.setting.pagestyle.realdark': '暗黑模式',\n  'app.setting.themecolor': '主题色',\n  'app.setting.navigationmode': '导航模式',\n  'app.setting.content-width': '内容区域宽度',\n  'app.setting.fixedheader': '固定 Header',\n  'app.setting.fixedsidebar': '固定侧边栏',\n  'app.setting.sidemenu': '侧边菜单布局',\n  'app.setting.topmenu': '顶部菜单布局',\n  'app.setting.content-width.fixed': 'Fixed',\n  'app.setting.content-width.fluid': 'Fluid',\n  'app.setting.othersettings': '其他设置',\n  'app.setting.weakmode': '色弱模式',\n  'app.setting.copy': '拷贝设置',\n  'app.setting.loading': '加载主题中',\n  'app.setting.copyinfo': '拷贝设置成功 src/config/defaultSettings.js',\n  'app.setting.production.hint': '配置栏只在开发环境用于预览，生产环境不会展现，请拷贝后手动修改配置文件',\n  'app.setting.themecolor.daybreak': '拂晓蓝',\n  'app.setting.themecolor.dust': '薄暮',\n  'app.setting.themecolor.volcano': '火山',\n  'app.setting.themecolor.sunset': '日暮',\n  'app.setting.themecolor.cyan': '明青',\n  'app.setting.themecolor.green': '极光绿',\n  'app.setting.themecolor.geekblue': '极客蓝',\n  'app.setting.themecolor.purple': '酱紫'\n});\n\n//# sourceURL=webpack://vue-antd-pro/./src/locales/lang/zh-CN/setting.js?\n}");

/***/ })

}]);