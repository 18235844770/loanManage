"use strict";
/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunkvue_antd_pro"] = self["webpackChunkvue_antd_pro"] || []).push([["lang-zh-CN-menu"],{

/***/ "./src/locales/lang/zh-CN/menu.js":
/*!****************************************!*\
  !*** ./src/locales/lang/zh-CN/menu.js ***!
  \****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony default export */ __webpack_exports__[\"default\"] = ({\n  'menu.welcome': '欢迎',\n  'menu.home': '主页',\n  'menu.dashboard': '仪表盘',\n  'menu.dashboard.analysis': '分析页',\n  'menu.dashboard.monitor': '监控页',\n  'menu.dashboard.workplace': '工作台',\n  'menu.form': '表单页',\n  'menu.form.basic-form': '基础表单',\n  'menu.form.step-form': '分步表单',\n  'menu.form.step-form.info': '分步表单（填写转账信息）',\n  'menu.form.step-form.confirm': '分步表单（确认转账信息）',\n  'menu.form.step-form.result': '分步表单（完成）',\n  'menu.form.advanced-form': '高级表单',\n  'menu.list': '列表页',\n  'menu.list.table-list': '查询表格',\n  'menu.list.basic-list': '标准列表',\n  'menu.list.card-list': '卡片列表',\n  'menu.list.search-list': '搜索列表',\n  'menu.list.search-list.articles': '搜索列表（文章）',\n  'menu.list.search-list.projects': '搜索列表（项目）',\n  'menu.list.search-list.applications': '搜索列表（应用）',\n  'menu.profile': '详情页',\n  'menu.profile.basic': '基础详情页',\n  'menu.profile.advanced': '高级详情页',\n  'menu.result': '结果页',\n  'menu.result.success': '成功页',\n  'menu.result.fail': '失败页',\n  'menu.exception': '异常页',\n  'menu.exception.not-permission': '403',\n  'menu.exception.not-find': '404',\n  'menu.exception.server-error': '500',\n  'menu.exception.trigger': '触发错误',\n  'menu.account': '个人页',\n  'menu.account.center': '个人中心',\n  'menu.account.settings': '个人设置',\n  'menu.account.trigger': '触发报错',\n  'menu.account.logout': '退出登录'\n});\n\n//# sourceURL=webpack://vue-antd-pro/./src/locales/lang/zh-CN/menu.js?\n}");

/***/ })

}]);