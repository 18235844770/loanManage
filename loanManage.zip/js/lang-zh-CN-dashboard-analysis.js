"use strict";
/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunkvue_antd_pro"] = self["webpackChunkvue_antd_pro"] || []).push([["lang-zh-CN-dashboard-analysis"],{

/***/ "./src/locales/lang/zh-CN/dashboard/analysis.js":
/*!******************************************************!*\
  !*** ./src/locales/lang/zh-CN/dashboard/analysis.js ***!
  \******************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony default export */ __webpack_exports__[\"default\"] = ({\n  'dashboard.analysis.test': '工专路 {no} 号店',\n  'dashboard.analysis.introduce': '指标说明',\n  'dashboard.analysis.total-sales': '总销售额',\n  'dashboard.analysis.day-sales': '日均销售额￥',\n  'dashboard.analysis.visits': '访问量',\n  'dashboard.analysis.visits-trend': '访问量趋势',\n  'dashboard.analysis.visits-ranking': '门店访问量排名',\n  'dashboard.analysis.day-visits': '日访问量',\n  'dashboard.analysis.week': '周同比',\n  'dashboard.analysis.day': '日同比',\n  'dashboard.analysis.payments': '支付笔数',\n  'dashboard.analysis.conversion-rate': '转化率',\n  'dashboard.analysis.operational-effect': '运营活动效果',\n  'dashboard.analysis.sales-trend': '销售趋势',\n  'dashboard.analysis.sales-ranking': '门店销售额排名',\n  'dashboard.analysis.all-year': '全年',\n  'dashboard.analysis.all-month': '本月',\n  'dashboard.analysis.all-week': '本周',\n  'dashboard.analysis.all-day': '今日',\n  'dashboard.analysis.search-users': '搜索用户数',\n  'dashboard.analysis.per-capita-search': '人均搜索次数',\n  'dashboard.analysis.online-top-search': '线上热门搜索',\n  'dashboard.analysis.the-proportion-of-sales': '销售额类别占比',\n  'dashboard.analysis.dropdown-option-one': '操作一',\n  'dashboard.analysis.dropdown-option-two': '操作二',\n  'dashboard.analysis.channel.all': '全部渠道',\n  'dashboard.analysis.channel.online': '线上',\n  'dashboard.analysis.channel.stores': '门店',\n  'dashboard.analysis.sales': '销售额',\n  'dashboard.analysis.traffic': '客流量',\n  'dashboard.analysis.table.rank': '排名',\n  'dashboard.analysis.table.search-keyword': '搜索关键词',\n  'dashboard.analysis.table.users': '用户数',\n  'dashboard.analysis.table.weekly-range': '周涨幅'\n});\n\n//# sourceURL=webpack://vue-antd-pro/./src/locales/lang/zh-CN/dashboard/analysis.js?\n}");

/***/ })

}]);